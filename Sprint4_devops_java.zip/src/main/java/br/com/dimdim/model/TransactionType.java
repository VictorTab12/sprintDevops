package br.com.dimdim.model;

public enum TransactionType {
	DEBIT, CREDIT
}
